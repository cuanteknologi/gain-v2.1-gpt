# GAIN 2.0 — Real Market / Testnet / Live Audit

## Scope
- Moonbot/AIOTrade explorer dan simulator dikeluarkan dari runtime trading.
- `/bot` menjadi satu halaman pusat seluruh bot.
- `/trading`, `/moonbot`, dan `/aiotrade` dipertahankan sebagai redirect kompatibilitas ke `/bot`.
- Paper execution dihapus dari bot deployment.
- Testnet dan Live menggunakan exchange API melalui CCXT.

## Execution modes
- `testnet`: wajib `isSandbox=true`, memakai credential Testnet/Sandbox exchange, dan benar-benar mengirim order ke endpoint sandbox.
- `live`: wajib credential Live, `LIVE_TRADING_ENABLED=true`, dan tetap tunduk pada `LIVE_TRADING_TESTNET_ONLY` jika guard tersebut aktif.
- Demo/dummy credentials ditolak oleh server.

## Real-market rules
- Tidak ada fallback harga hard-coded untuk ticker bot.
- Tidak ada fake balance/portfolio.
- Tidak ada fake order ID/fill.
- Tidak ada CoinGecko fallback pada batch ticker exchange-specific.
- Jika exchange tidak memberi market data, endpoint mengembalikan error.
- Sebelum order dikirim, bot membutuhkan harga exchange yang fresh.
- Order state baru dianggap filled setelah exchange mengonfirmasi fill.

## Bot architecture
1. Exchange WebSocket/REST market data
2. Strategy engine (DCA/Grid/Hybrid)
3. Risk Engine
4. Exchange order execution
5. Fill confirmation
6. Runner persistence/reconciliation
7. UI refresh/status

## Verification performed
- Whole-source TypeScript syntax parse: PASS.
- Relative import resolution: PASS.
- DCA layer generation + base trigger runtime smoke: PASS.
- Grid generation runtime smoke: PASS.
- Risk spread rejection runtime smoke: PASS.
- OMS create/transition/idempotency runtime smoke: PASS.
- Production simulator marker scan: PASS.

## Environment limitation
A full `npm ci` could not complete in this execution environment because dependency installation timed out and the available `node_modules` tree was incomplete. Therefore a full Vite/TypeScript type-check and an actual exchange-network order could not be claimed as executed here.

## Required final external test
Use a staging deployment with real Testnet API credentials and run one complete lifecycle:
`connect -> fetch balance -> fetch ticker -> register bot -> trigger -> risk approve -> create order -> fetch order -> fill -> persist -> reconcile -> restart -> restore`.
Only after that signoff should Live be enabled.
