import type { MarketSnapshot } from '../../domain/strategy/types';
import { MarketDataEngine } from './MarketDataEngine';

interface Connection { ws: WebSocket; exchange: string; symbol: string; reconnectTimer?: ReturnType<typeof setTimeout>; }

function binanceSymbol(symbol: string) { return symbol.replace('/', '').toLowerCase(); }
function bitgetSymbol(symbol: string) { return symbol.replace('/', '').toUpperCase(); }
function okxSymbol(symbol: string) { return symbol.replace('/', '-').toUpperCase(); }

/** Native WebSocket market-data gateway. It is intentionally read-only: orders never travel over this channel. */
export class WebSocketManager {
  private readonly connections = new Map<string, Connection>();
  constructor(private readonly marketData: MarketDataEngine) {}

  connect(exchange: string, symbol: string): void {
    const key = `${exchange.toLowerCase()}:${symbol}`;
    if (this.connections.has(key)) return;
    const normalized = exchange.toLowerCase();
    const url = normalized === 'binance'
      ? `wss://stream.binance.com:9443/ws/${binanceSymbol(symbol)}@ticker`
      : normalized === 'okx'
        ? 'wss://ws.okx.com:8443/ws/v5/public'
        : 'wss://ws.bitget.com/v2/ws/public';
    const ws = new WebSocket(url);
    const connection: Connection = { ws, exchange: normalized, symbol };
    this.connections.set(key, connection);
    ws.onopen = () => {
      if (normalized === 'okx') ws.send(JSON.stringify({ op:'subscribe', args:[{ channel:'tickers', instId:okxSymbol(symbol) }] }));
      if (normalized === 'bitget') ws.send(JSON.stringify({ op:'subscribe', args:[{ instType:'SPOT', channel:'ticker', instId:bitgetSymbol(symbol) }] }));
    };
    ws.onmessage = (event) => {
      try {
        const raw = JSON.parse(String(event.data));
        const tick = this.normalize(normalized, symbol, raw);
        if (tick) this.marketData.publish(tick);
      } catch { /* malformed feed is ignored; REST reconciliation remains authoritative */ }
    };
    ws.onerror = () => this.scheduleReconnect(key);
    ws.onclose = () => this.scheduleReconnect(key);
  }

  disconnect(exchange: string, symbol: string) {
    const key = `${exchange.toLowerCase()}:${symbol}`;
    const connection = this.connections.get(key);
    if (!connection) return;
    this.connections.delete(key);
    if (connection.reconnectTimer) clearTimeout(connection.reconnectTimer);
    connection.ws.close();
  }

  private scheduleReconnect(key: string) {
    const connection = this.connections.get(key);
    if (!connection || connection.reconnectTimer) return;
    connection.reconnectTimer = setTimeout(() => {
      this.connections.delete(key);
      this.connect(connection.exchange, connection.symbol);
    }, 1000);
  }

  private normalize(exchange: string, symbol: string, raw: any): MarketSnapshot | undefined {
    let last = 0; let bid = 0; let ask = 0; let timestamp = Date.now(); let percentage = 0;
    if (exchange === 'binance') {
      last = Number(raw.c); bid = Number(raw.b); ask = Number(raw.a); timestamp = Number(raw.E) || Date.now();
      const open = Number(raw.o); percentage = open > 0 ? ((last - open) / open) * 100 : 0;
    } else {
      const data = Array.isArray(raw?.data) ? raw.data[0] : raw?.data;
      last = Number(data?.last); bid = Number(data?.bidPr); ask = Number(data?.askPr); timestamp = Number(data?.ts) || Date.now();
      if (exchange === 'okx') { last = Number(data?.last); bid = Number(data?.bidPx); ask = Number(data?.askPx); }
    }
    if (!(last > 0) || !(bid > 0) || !(ask > 0)) return undefined;
    return { exchange, symbol, bid, ask, last, timestamp, spreadPct: ((ask - bid) / last) * 100, volatilityPct: Math.abs(percentage) };
  }
}
