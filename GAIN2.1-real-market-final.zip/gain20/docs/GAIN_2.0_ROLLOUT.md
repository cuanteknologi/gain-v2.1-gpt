# GAIN 2.0 rollout checklist

## Phase A — strategy/risk validation tanpa order
1. `GAIN_V2_ENABLED=true`
2. Validate strategy/risk state transitions using unit/runtime tests.
3. No fake fills are used by the production bot path.
4. Verify DCA base order, layer generation, capital cap and reset after TP.
5. Verify Grid requires explicit `minPrice` and `maxPrice` and uses price-cross events.
6. Verify every rejected order produces a risk event/log.

## Phase B — exchange testnet
1. Configure real exchange Testnet/Sandbox credentials.
2. `LIVE_TRADING_ENABLED` is not required for `mode: "testnet"`; the bot must use `isSandbox=true`.
3. Run startup reconciliation.
4. Force timeout/429/unknown-order scenarios.
5. Verify duplicate retry uses the same client order id.

## Phase C — production adapters
1. Implement PostgreSQL `OrderStore` and repositories.
2. Implement Redis `DistributedLock`, `EventBus`, and distributed rate limiter.
3. Replace in-memory market feed with the WebSocket gateway.
4. Add persistent market snapshots/orderbook metrics.
5. Run load and failure tests.

## Phase D — live capital
Only after the above gates pass. Keep hard caps lower than the business maximum initially and increase only from observed operational data.
