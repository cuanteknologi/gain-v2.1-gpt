# GAIN 2.0 implementation

GAIN 2.0 introduces isolated trading domains under `src/v2` while retaining the existing GAIN engine as a compatibility path.

## Modules
- `engines/marketData`: normalized event-driven market snapshots.
- `engines/strategy/DcaEngine`: true layered DCA with step scaling and volume multiplier.
- `engines/strategy/GridEngine`: independent grid levels and grid state.
- `engines/risk/RiskEngine`: exposure, committed capital, spread, slippage, drawdown, daily-loss and kill-switch checks.
- `engines/oms/OrderManager`: idempotent order state machine.
- `engines/reconciliation`: internal/exchange state comparison.
- `ai`: regime detection and bounded strategy recommendations. AI never bypasses RiskEngine.
- `infrastructure`: ports for Redis/event bus/distributed locks; memory adapters are included so the source can run without extra packages.

## Production adapters
Implement `ExchangePort`, `OrderStore`, `DistributedLock`, and `EventBus` with CCXT, PostgreSQL, Redis/BullMQ or equivalent before enabling high-scale live trading.

## Database
Apply `db/migrations/*.sql` to PostgreSQL. Firebase remains appropriate for authentication/UI metadata; the trade ledger belongs in PostgreSQL.

## Important
The existing live runner is intentionally retained as a compatibility path. Do not route real-money orders through the new v2 path until the production adapters, testnet verification, reconciliation and failure drills have been completed.

### Grid execution note
The v2 Grid engine is now a separate level/crossing planner and risk-gated intent producer. The existing exchange execution path still confirms immediate fills and is not yet a persistent resting-limit-order OMS. For real grid deployment, implement persistent `OPEN` limit orders plus cancel/replace and fill reconciliation before relying on unattended grid inventory.
